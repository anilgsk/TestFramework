package com.salesforce.pages;

public class SampleJava {

}
